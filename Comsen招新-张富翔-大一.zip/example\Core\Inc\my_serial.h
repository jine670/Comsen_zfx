#ifndef MY_SERIAL_H
#define MY_SERIAL_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 阶段 2：USB 虚拟串口（CDC）收发封装。
 *
 * 说明：
 *   - USB 外设本身由 CubeMX 生成的 usb_device.c 初始化（main 里调用
 *     MX_USB_DEVICE_Init）。
 *   - 收到数据时，usbd_cdc_if.c 的 CDC_Receive_FS 会调用 my_serial_on_rx()
 *     把数据放进环形缓冲。
 *   - 主循环里用 my_serial_available() / my_serial_read() 取数据。
 *   - 用 my_serial_send() 把数据发回电脑（比如回显）。
 */

void my_serial_init(void);

/* USB 收到一包数据时由中断回调调用 */
void my_serial_on_rx(const uint8_t *data, uint32_t len);

/* 缓冲里还有多少字节可读 */
uint32_t my_serial_available(void);

/* 读一个字节；没有数据时返回 0 */
uint8_t my_serial_read(void);

/* 发送 len 个字节回电脑 */
void my_serial_send(const uint8_t *data, uint16_t len);

#ifdef __cplusplus
}
#endif

#endif /* MY_SERIAL_H */
