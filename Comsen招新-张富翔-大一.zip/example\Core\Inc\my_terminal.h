#ifndef MY_TERMINAL_H
#define MY_TERMINAL_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 1602 “打字机”终端：把串口收到的字节流显示到 2 行 x 16 字符的屏幕上。
 *
 * 相比最简单的“写满 32 字符回到开头”，这里做的是真正的终端行为：
 *   - 写满一行自动换到下一行
 *   - 已经在第 2 行还要换行时，整屏向上滚动一行（第 2 行 → 第 1 行，第 2 行清空）
 *   - '\r' 回到行首、'\n' 换行、'\b'/0x7F 退格（行首退格会退回上一行末）
 *   - 只接受 0x20~0x7E 的可打印字符，其它（中文 UTF-8、控制符）直接忽略
 */

#define MY_TERM_COLS 16U
#define MY_TERM_ROWS 2U

void my_terminal_init(void);

/* 喂一个字节（来自串口） */
void my_terminal_feed(uint8_t ch);

/* 一次喂一串（比如开机横幅） */
void my_terminal_puts(const char *s);

/* 清屏并把光标归零 */
void my_terminal_clear(void);

/* 取出两行显示内容（各 16 字节，不做字符串结尾，和 lcd1602 库一致） */
void my_terminal_lines(char line1[16], char line2[16]);

#ifdef __cplusplus
}
#endif

#endif /* MY_TERMINAL_H */
