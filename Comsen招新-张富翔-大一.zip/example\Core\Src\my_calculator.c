#include "my_calculator.h"
#include <math.h>
#include <string.h>

/* ============================================================================
 * 内部小工具
 * ========================================================================== */

static char key_to_char(my_calc_key_t key)
{
    if (key <= MY_CALC_KEY_9)
    {
        return (char)('0' + (key - MY_CALC_KEY_0));
    }
    switch (key)
    {
    case MY_CALC_KEY_DECIMAL: return '.';
    case MY_CALC_KEY_ADD:     return '+';
    case MY_CALC_KEY_SUB:     return '-';
    case MY_CALC_KEY_MUL:     return '*';
    case MY_CALC_KEY_DIV:     return '/';
    default:                  return '\0';
    }
}

static uint8_t is_digit(char ch)
{
    return ch >= '0' && ch <= '9';
}

static uint8_t is_operator(char ch)
{
    return ch == '+' || ch == '-' || ch == '*' || ch == '/';
}

/* 安全地复制字符串（最多 n 个字节，含结尾 '\0'） */
static void my_strncpy(char *dst, const char *src, size_t n)
{
    size_t i = 0;
    if (n == 0)
    {
        return;
    }
    while (i + 1 < n && src[i] != '\0')
    {
        dst[i] = src[i];
        i++;
    }
    dst[i] = '\0';
}

/* 可显示的最大绝对值：超过就报 Overflow（同时保证整数部分不超过 9 位） */
#define MY_CALC_MAX_MAGNITUDE 999999999.0f

/* ============================================================================
 * 浮点数格式化：最多 6 位小数，去掉末尾多余的 0。
 * 刻意不用 printf 的 %f/%g，避免目标机上为浮点打印额外链接库。
 * ========================================================================== */
static void format_float(float value, char *buf, size_t maxlen)
{
    char tmp[24];
    size_t pos = 0;

    if (maxlen == 0)
    {
        return;
    }

    if (isnan(value))
    {
        my_strncpy(buf, "NaN", maxlen);
        return;
    }
    if (value > MY_CALC_MAX_MAGNITUDE || value < -MY_CALC_MAX_MAGNITUDE)
    {
        my_strncpy(buf, "Overflow", maxlen);
        return;
    }

    if (value < 0.0f)
    {
        tmp[pos++] = '-';
        value = -value;
    }

    /* 四舍五入到 6 位小数 */
    {
        float scaled = value * 1000000.0f;
        long long rounded = (long long)(scaled + 0.5f);
        long long int_part = rounded / 1000000LL;
        long long frac_part = rounded % 1000000LL;

        /* 整数部分（逆序生成再反转） */
        char ipart[16];
        int ipos = 0;
        if (int_part == 0)
        {
            ipart[ipos++] = '0';
        }
        else
        {
            while (int_part > 0)
            {
                ipart[ipos++] = (char)('0' + (int_part % 10));
                int_part /= 10;
            }
        }
        while (ipos > 0)
        {
            tmp[pos++] = ipart[--ipos];
        }

        /* 小数部分：生成 6 位，再去掉末尾 0 */
        if (frac_part != 0)
        {
            char fpart[7];
            int i;
            for (i = 0; i < 6; i++)
            {
                fpart[6 - 1 - i] = (char)('0' + (frac_part % 10));
                frac_part /= 10;
            }
            tmp[pos++] = '.';
            {
                int len6 = 6;
                while (len6 > 0 && fpart[len6 - 1] == '0')
                {
                    len6--;
                }
                for (i = 0; i < len6; i++)
                {
                    tmp[pos++] = fpart[i];
                }
            }
        }
    }

    tmp[pos] = '\0';
    my_strncpy(buf, tmp, maxlen);
}

/* ============================================================================
 * 表达式求值：递归下降，支持 + - * / 和一元负号（不带括号）
 *   表达式 := 项 (('+' | '-') 项)*
 *   项     := 因子 (('*' | '/') 因子)*
 *   因子   := ['-'] 数字
 *   数字   := 数字序列 ['.' 数字序列]
 * ========================================================================== */
typedef struct
{
    const char *p;
    uint8_t err; /* 0=正常, 1=除零, 2=语法错误 */
} parser_t;

static float parse_expr(parser_t *ps);

static float parse_number(parser_t *ps)
{
    float value = 0.0f;
    uint8_t any = 0;

    while (is_digit(*ps->p))
    {
        value = value * 10.0f + (float)(*ps->p - '0');
        ps->p++;
        any = 1;
    }
    if (*ps->p == '.')
    {
        float scale = 0.1f;
        ps->p++;
        while (is_digit(*ps->p))
        {
            value += (float)(*ps->p - '0') * scale;
            scale *= 0.1f;
            ps->p++;
            any = 1;
        }
    }

    if (!any)
    {
        ps->err = MY_CALC_ERR_SYNTAX;
    }
    return value;
}

static float parse_factor(parser_t *ps)
{
    if (*ps->p == '-')
    {
        ps->p++;
        return -parse_factor(ps);
    }
    return parse_number(ps);
}

static float parse_term(parser_t *ps)
{
    float left = parse_factor(ps);
    while (*ps->p == '*' || *ps->p == '/')
    {
        char op = *ps->p++;
        float right = parse_factor(ps);
        if (op == '*')
        {
            left = left * right;
        }
        else
        {
            if (right == 0.0f)
            {
                ps->err = MY_CALC_ERR_DIV0;
                left = 0.0f;
            }
            else
            {
                left = left / right;
            }
        }
    }
    return left;
}

static float parse_expr(parser_t *ps)
{
    float left = parse_term(ps);
    while (*ps->p == '+' || *ps->p == '-')
    {
        char op = *ps->p++;
        float right = parse_term(ps);
        if (op == '+')
        {
            left = left + right;
        }
        else
        {
            left = left - right;
        }
    }
    return left;
}

static float my_calc_evaluate(const char *expr, uint8_t *err)
{
    parser_t ps;
    ps.p = expr;
    ps.err = MY_CALC_OK;

    float result = parse_expr(&ps);

    if (ps.err != MY_CALC_OK)
    {
        *err = ps.err;
        return 0.0f;
    }

    /* 允许结尾有空格，但不允许有多余字符 */
    while (*ps.p == ' ')
    {
        ps.p++;
    }
    if (*ps.p != '\0')
    {
        *err = MY_CALC_ERR_SYNTAX;
        return 0.0f;
    }

    /* 结果是否可显示 */
    if (isnan(result) || isinf(result) ||
        result > MY_CALC_MAX_MAGNITUDE || result < -MY_CALC_MAX_MAGNITUDE)
    {
        *err = MY_CALC_ERR_OVERFLOW;
        return 0.0f;
    }

    *err = MY_CALC_OK;
    return result;
}

/* ============================================================================
 * 对外接口
 * ========================================================================== */

void my_calc_init(my_calc_t *c)
{
    memset(c, 0, sizeof(*c));
    c->error = MY_CALC_OK;
}

void my_calc_input(my_calc_t *c, my_calc_key_t key)
{
    /* 出错后只有 AC 能恢复 */
    if (c->error != MY_CALC_OK && key != MY_CALC_KEY_CLEAR)
    {
        return;
    }

    if (key == MY_CALC_KEY_CLEAR)
    {
        my_calc_init(c);
        return;
    }

    if (key == MY_CALC_KEY_BACKSPACE)
    {
        if (c->len > 0)
        {
            c->expr[--c->len] = '\0';
        }
        c->has_result = 0;
        return;
    }

    if (key == MY_CALC_KEY_EQUALS)
    {
        if (c->len == 0)
        {
            return;
        }
        c->result = my_calc_evaluate(c->expr, &c->error);
        c->has_result = (c->error == MY_CALC_OK);
        return;
    }

    /* 数字或小数点 */
    if (key <= MY_CALC_KEY_DECIMAL)
    {
        char ch = key_to_char(key);

        /* 刚算完：直接输入数字表示开始新的算式 */
        if (c->has_result)
        {
            if (ch == '.')
            {
                my_calc_init(c);
                c->expr[0] = '0';
                c->expr[1] = '.';
                c->len = 2;
                c->expr[c->len] = '\0';
                return;
            }
            my_calc_init(c);
        }

        if (ch == '.')
        {
            /* 当前这个数字里已经有点，则忽略 */
            uint8_t i = c->len;
            uint8_t has_dot = 0;
            while (i > 0 && !is_operator(c->expr[i - 1]))
            {
                if (c->expr[i - 1] == '.')
                {
                    has_dot = 1;
                    break;
                }
                i--;
            }
            if (has_dot)
            {
                return;
            }
            /* 小数点出现在开头或运算符后：补 0 */
            if (c->len == 0 || is_operator(c->expr[c->len - 1]))
            {
                if (c->len < MY_CALC_MAX_EXPR)
                {
                    c->expr[c->len++] = '0';
                    c->expr[c->len] = '\0';
                }
            }
        }

        if (c->len < MY_CALC_MAX_EXPR)
        {
            c->expr[c->len++] = ch;
            c->expr[c->len] = '\0';
        }
        return;
    }

    /* 运算符 */
    {
        char ch = key_to_char(key);

        if (c->len == 0)
        {
            /* 空算式：只有负号可作为一元负号开头 */
            if (ch == '-' && c->len < MY_CALC_MAX_EXPR)
            {
                c->expr[c->len++] = ch;
                c->expr[c->len] = '\0';
                c->has_result = 0;
            }
            return;
        }

        /* 刚算完：用结果作为新算式的开头继续运算 */
        if (c->has_result)
        {
            format_float(c->result, c->expr, sizeof(c->expr));
            c->len = (uint8_t)strlen(c->expr);
            c->has_result = 0;
        }

        if (is_operator(c->expr[c->len - 1]))
        {
            /* 负号跟在运算符后面是一元负号（如 2*-3、2+-3）；
               其它情况替换最后一个运算符（如 2*+3 -> 2+3）。 */
            if (ch == '-' && c->expr[c->len - 1] != '-')
            {
                if (c->len < MY_CALC_MAX_EXPR)
                {
                    c->expr[c->len++] = ch;
                    c->expr[c->len] = '\0';
                }
            }
            else
            {
                c->expr[c->len - 1] = ch;
            }
        }
        else if (c->len < MY_CALC_MAX_EXPR)
        {
            c->expr[c->len++] = ch;
            c->expr[c->len] = '\0';
        }
    }
}

void my_calc_get_lines(const my_calc_t *c, char line1[16], char line2[16])
{
    size_t i;
    char text[16];

    /* 第一行：算式，左对齐，补空格 */
    for (i = 0; i < 16; i++)
    {
        line1[i] = (i < c->len) ? c->expr[i] : ' ';
    }

    /* 第二行：结果或错误 */
    if (c->error == MY_CALC_ERR_DIV0)
    {
        my_strncpy(text, "Err: Div/0", sizeof(text));
    }
    else if (c->error == MY_CALC_ERR_SYNTAX)
    {
        my_strncpy(text, "Err: Syntax", sizeof(text));
    }
    else if (c->error == MY_CALC_ERR_OVERFLOW)
    {
        my_strncpy(text, "Overflow", sizeof(text));
    }
    else if (c->has_result)
    {
        format_float(c->result, text, sizeof(text));
    }
    else
    {
        text[0] = '\0';
    }

    /* text 最多到第一个 '\0' 就结束了，剩余位置一律补空格，
       不能继续读 text 未初始化的部分 */
    for (i = 0; i < 16; i++)
    {
        line2[i] = ' ';
    }
    for (i = 0; i < 16 && text[i] != '\0'; i++)
    {
        line2[i] = text[i];
    }
}
