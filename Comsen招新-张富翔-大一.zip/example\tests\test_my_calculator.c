/* my_calculator 的宿主机单元测试（在 Linux/WSL 上直接跑，不需要开发板） */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "my_calculator.h"

static int g_fail = 0;

/* 把一串按键字符喂给计算器：0-9 . + - * / = C(AC) B(退格) */
static void press(my_calc_t *c, const char *keys)
{
    while (*keys)
    {
        my_calc_key_t k;
        char ch = *keys++;
        switch (ch)
        {
        case '0': case '1': case '2': case '3': case '4':
        case '5': case '6': case '7': case '8': case '9':
            k = (my_calc_key_t)(MY_CALC_KEY_0 + (ch - '0'));
            break;
        case '.': k = MY_CALC_KEY_DECIMAL; break;
        case '+': k = MY_CALC_KEY_ADD; break;
        case '-': k = MY_CALC_KEY_SUB; break;
        case '*': k = MY_CALC_KEY_MUL; break;
        case '/': k = MY_CALC_KEY_DIV; break;
        case '=': k = MY_CALC_KEY_EQUALS; break;
        case 'C': k = MY_CALC_KEY_CLEAR; break;
        case 'B': k = MY_CALC_KEY_BACKSPACE; break;
        default: continue;
        }
        my_calc_input(c, k);
    }
}

/* 检查计算结果（浮点，容差） */
static void check_result(my_calc_t *c, float expect, const char *msg)
{
    if (c->error == MY_CALC_OK && c->has_result && fabsf(c->result - expect) < 1e-4f)
    {
        printf("  PASS  %s (got %g)\n", msg, (double)c->result);
    }
    else
    {
        printf("  FAIL  %s (error=%d has_result=%d got %g, want %g)\n",
               msg, c->error, c->has_result, (double)c->result, (double)expect);
        g_fail++;
    }
}

static void check_error(my_calc_t *c, my_calc_err_t expect, const char *msg)
{
    if (c->error == expect)
    {
        printf("  PASS  %s\n", msg);
    }
    else
    {
        printf("  FAIL  %s (error=%d, want %d)\n", msg, c->error, (int)expect);
        g_fail++;
    }
}

static void check_lines(my_calc_t *c, const char *l1, const char *l2, const char *msg)
{
    char a[16], b[16];
    my_calc_get_lines(c, a, b);
    if (memcmp(a, l1, 16) == 0 && memcmp(b, l2, 16) == 0)
    {
        printf("  PASS  %s\n", msg);
    }
    else
    {
        printf("  FAIL  %s\n        got  L1='%.16s' L2='%.16s'\n        want L1='%s' L2='%s'\n",
               msg, a, b, l1, l2);
        g_fail++;
    }
}

int main(void)
{
    my_calc_t c;

    printf("== 基本四则运算 ==\n");
    my_calc_init(&c); press(&c, "1+2="); check_result(&c, 3, "1+2=3");
    my_calc_init(&c); press(&c, "7-4="); check_result(&c, 3, "7-4=3");
    my_calc_init(&c); press(&c, "5*6="); check_result(&c, 30, "5*6=30");
    my_calc_init(&c); press(&c, "10/2="); check_result(&c, 5, "10/2=5");

    printf("== 运算符优先级 ==\n");
    my_calc_init(&c); press(&c, "1+2*3="); check_result(&c, 7, "1+2*3=7");
    my_calc_init(&c); press(&c, "2*3+4="); check_result(&c, 10, "2*3+4=10");
    my_calc_init(&c); press(&c, "12-8/4="); check_result(&c, 10, "12-8/4=10");

    printf("== 小数 ==\n");
    my_calc_init(&c); press(&c, "1.5+2.5="); check_result(&c, 4, "1.5+2.5=4");
    my_calc_init(&c); press(&c, "0.5*4="); check_result(&c, 2, "0.5*4=2");
    my_calc_init(&c); press(&c, ".5+.5="); check_result(&c, 1, ".5+.5=1");

    printf("== 一元负号 ==\n");
    my_calc_init(&c); press(&c, "-5+3="); check_result(&c, -2, "-5+3=-2");
    my_calc_init(&c); press(&c, "2*-3="); check_result(&c, -6, "2*-3=-6");

    printf("== 连续运算 ==\n");
    my_calc_init(&c); press(&c, "1+2+3="); check_result(&c, 6, "1+2+3=6");

    printf("== 用结果继续算 ==\n");
    my_calc_init(&c); press(&c, "1+2=+4="); check_result(&c, 7, "(1+2) 再 +4 = 7");

    printf("== 错误处理 ==\n");
    my_calc_init(&c); press(&c, "5/0="); check_error(&c, MY_CALC_ERR_DIV0, "5/0 除零");
    my_calc_init(&c); press(&c, "1+="); check_error(&c, MY_CALC_ERR_SYNTAX, "1+= 语法错误");
    my_calc_init(&c); press(&c, "5/0=C1+1="); check_result(&c, 2, "出错后 AC 能恢复");

    printf("== 重复按 = ==\n");
    my_calc_init(&c); press(&c, "2+3=="); check_result(&c, 5, "2+3== 结果不变");

    printf("== 退格 ==\n");
    my_calc_init(&c); press(&c, "123B="); check_result(&c, 12, "123 退格 -> 12");
    my_calc_init(&c); press(&c, "12+3B4="); check_result(&c, 16, "12+3 退格删 3 再 +4 = 16");

    printf("== 结果格式化（两行显示） ==\n");
    my_calc_init(&c); press(&c, "1/3=");
    check_lines(&c, "1/3             ", "0.333333        ", "1/3 显示 0.333333");
    my_calc_init(&c); press(&c, "2.5=");
    check_lines(&c, "2.5             ", "2.5             ", "2.5 去掉多余 0");
    my_calc_init(&c); press(&c, "5/0=");
    check_lines(&c, "5/0             ", "Err: Div/0      ", "除零显示错误");

    printf("\n%s\n", g_fail == 0 ? "全部通过 ✓" : "存在失败 ✗");
    return g_fail == 0 ? 0 : 1;
}
