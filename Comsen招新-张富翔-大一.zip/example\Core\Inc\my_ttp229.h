#ifndef MY_TTP229_H
#define MY_TTP229_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 阶段 3：自己实现 TTP229 触摸按键读取。
 *
 * 板上两颗 TTP229，各自用两线 GPIO 时序（不是标准 I2C）读回 16 位：
 *   - A 片：PB6 = 数据线(输出)，PB7 = 回读线(输入)
 *   - B 片：PB8 = 数据线(输出)，PB9 = 回读线(输入)
 *
 * 时序：把数据线拉高 -> 等约 5us -> 读回读线得到一个 bit -> 拉低 -> 等约 5us。
 * 延时用 TIM3 计数器（配置为 1MHz，调用前需已启动 HAL_TIM_Base_Start）。
 *
 * 返回 32 位位图，bit0..bit29 对应物理按键 T0..T29。
 */

uint32_t my_ttp229_read_physical(void);

/* 读单颗芯片的 16 位原始数据（data_pin/input_pin 用 GPIO_PIN_x 定义），
 * 供调试和理解协议用；my_ttp229_read_physical 内部会调用它。 */
uint32_t my_ttp229_read_chip(uint16_t data_pin, uint16_t input_pin);

#ifdef __cplusplus
}
#endif

#endif /* MY_TTP229_H */
