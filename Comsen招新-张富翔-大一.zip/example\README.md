# ComSen 硬件组招新 · 我的实现说明

> 这个工程在原示例 `example/` 的基础上，**自己重写了串口、按键、计算器和应用主循环**，
> 只保留了官方提供的 `liblcd1602.a`（1602 显示库）。另外加了三个调试/自检模块。

## 一、我自己写的模块

| 文件 | 作用 | 说明 |
|---|---|---|
| `Core/Src/my_serial.c` / `.h` | USB 虚拟串口收发 | 环形缓冲区 + 中断回调 `my_serial_on_rx()`，主循环非阻塞取数据；`my_serial_send()` 回发 |
| `Core/Src/my_ttp229.c` / `.h` | TTP229 电容触摸读取 | 两颗 TTP229 各 16 通道，用 GPIO 软件时序（SCL/SDO）逐位读出；通道→物理按键号 T0~T29 的映射表；直接操作 `GPIOB->BSRR/IDR` + TIM3 微秒延时保证时序 |
| `Core/Src/my_calculator.c` / `.h` | 计算器核心 | 手写四则运算解析（数字累积 + 运算符栈 + 浮点结果），支持 `AC` 清空、小数、负号、退格；`tests/test_my_calculator.c` 有 24 条单元测试，全部通过 |
| `Core/Src/my_app.c` / `.h` | 应用层主循环（裸机，不跑 RTOS） | `while(1)` 依次做：扫按键（10ms 节拍 + 去抖）→ 处理串口数据 → 刷新 1602；三种界面模式：计算器 / 串口终端 / 板卡信息 |
| `Core/Src/board_info.c` / `.h` | 板卡 + 固件信息自检 | 直接读寄存器取器件 ID、Rev、Flash 容量、96 位 UID、SYSCLK/APB/USB 时钟、GPIOB 配置、TIM3 预分频；并从链接脚本符号算镜像大小、向量表、**整片 Flash 的 CRC32**；输出到串口 + 1602 分页显示 |
| `Core/Src/lcd_probe.c` / `.h` | 1602 硬件自检（调试用） | 不依赖 `liblcd1602.a`，自己按 4 位时序（RS=PB10、EN=PB11、D4~D7=PB12~PB15）初始化，分四阶段往屏幕写文字/实心块/开关显示/移动黑块，用于分辨「对比度 / 数据线 / 命令通道」哪一层出问题 |
| `Core/Src/pin_ping.c` / `.h` | 引脚级链路验证（调试用） | 把候选引脚逐个单独拉高（串口报名字、LED 指示），并回读 `IDR` 判断是否短路到地/电源；最后让 EN 引脚 1Hz 翻转，方便万用表测量 |

## 二、保留的官方库

| 库 | 用途 |
|---|---|
| `lib/liblcd1602.a` | 1602 字符显示（只用到 `lcd1602_init()` / `lcd1602_write_lines()`） |

`lib/` 里的 `libttp229.a`、`libtouch_filter.a`、`libcalculator_*.a` **都没有链接**，对应的功能全部自己实现。

## 三、编译方法

主开发环境是 WSL Ubuntu（工具链在仓库根的 `toolchain/`，按官方 README 安装一次即可）：

```bash
cd ~/Comsen_recruitment_hardware/example
bash build.sh Release
# 产物：build/Release/software.elf / software.hex / software.bin
```

烧录（STM32CubeProgrammer CLI，SWD）：

```powershell
& "C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\bin\STM32_Programmer_CLI.exe" `
  -c port=SWD freq=100 mode=UR reset=HWrst -w software.hex -v -rst
```

当前占用：FLASH 约 27~29 KB / 64 KB，RAM 5.4 KB / 20 KB。

## 四、当前状态 / 已知问题

- 阶段 2（串口→屏幕）、阶段 3（按键读取）、阶段 4（四则 + AC）代码已完成，计算器逻辑 24 条单元测试通过；
- 板载 LED（PC13）心跳闪烁正常，说明主循环在跑；`board_info` 自检读到的寄存器（RCC 72MHz、TIM3 1MHz、GPIOB 配置）全部符合预期；
- **1602 目前只亮背光、不显示字符**，正在用 `lcd_probe` / `pin_ping` 定位是「V0 对比度」「模块接插方向」还是「板子到 LCD 的走线/焊点」问题。

## 五、目录

```
example/
├── CMakeLists.txt              # 已加入我自己的 6 个源文件
├── Core/Inc|Src/               # 我的模块 + CubeMX 生成代码
├── lib/liblcd1602.a            # 唯二保留的官方库
├── tests/                      # 计算器单元测试（Windows/MinGW 可直接 gcc 编译）
├── USB_DEVICE/                 # CubeMX 生成的 USB CDC
└── software.ioc                # 引脚/时钟配置（PB10~PB15=LCD，PB6~PB9=TTP229，PC13=LED）
```
