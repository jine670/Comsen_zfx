#include "pin_ping.h"

#include "main.h"      /* HAL、GPIOA / GPIOB / GPIOC */
#include "my_serial.h" /* USB 虚拟串口：把每一步打到电脑上 */

/*
 * 最简信号链路验证（不跑显示库、不跑计算器，只拨 GPIO）
 *
 * 为什么同时驱两组引脚：
 *   software.ioc 里 LCD 是 PB10..PB15，但你现在可能已经把它改插到 PA0..PA5，
 *   两边都驱相同的信号，**不管你插哪一组，EN 都会 1Hz 翻转**，万用表都能量到。
 *
 * 接线（你要求的一对一，别插到相邻脚）：
 *   PA0 -> LCD 第 4 脚 RS
 *   PA1 -> LCD 第 6 脚 E (EN)
 *   PA2 -> LCD 第 11 脚 D4
 *   PA3 -> LCD 第 12 脚 D5
 *   PA4 -> LCD 第 13 脚 D6
 *   PA5 -> LCD 第 14 脚 D7
 *   （LCD 第 1 脚 VSS=GND、第 2 脚 VDD=5V、第 3 脚 V0=电位器、15/16 脚=背光，仍要供电）
 *
 * 固件行为：
 *   A 段：12 个候选引脚（PA0-PA5、PB10-PB15）逐个单独拉高 2 秒，
 *         串口会打出“现在是哪根脚高”，此时板载 LED 常亮；用来找线。
 *   B 段：PA1 和 PB11 同步做 1Hz 翻转 10 秒，**LED 跟着 EN 一起亮灭**，
 *         万用表点 LCD 第 6 脚应看到 0V <-> 3.3V 来回跳。
 */

#define CAND_N 12U

typedef struct
{
    GPIO_TypeDef *port;
    uint16_t      pin;
    const char   *name;
} cand_t;

static const cand_t cand[CAND_N] = {
    { GPIOA, GPIO_PIN_0,  "PA0  (RS?)" },
    { GPIOA, GPIO_PIN_1,  "PA1  (EN?)" },
    { GPIOA, GPIO_PIN_2,  "PA2  (D4?)" },
    { GPIOA, GPIO_PIN_3,  "PA3  (D5?)" },
    { GPIOA, GPIO_PIN_4,  "PA4  (D6?)" },
    { GPIOA, GPIO_PIN_5,  "PA5  (D7?)" },
    { GPIOB, GPIO_PIN_10, "PB10 (RS)" },
    { GPIOB, GPIO_PIN_11, "PB11 (EN)" },
    { GPIOB, GPIO_PIN_12, "PB12 (D4)" },
    { GPIOB, GPIO_PIN_13, "PB13 (D5)" },
    { GPIOB, GPIO_PIN_14, "PB14 (D6)" },
    { GPIOB, GPIO_PIN_15, "PB15 (D7)" },
};

static void ping_log(const char *s)
{
    uint16_t n = 0;
    while (s[n] != '\0')
    {
        n++;
    }
    my_serial_send((const uint8_t *)s, n);
    my_serial_send((const uint8_t *)"\r\n", 2U);
    HAL_Delay(3);
}

/* 把 12 根候选脚全部配成推挽输出、初始低电平 */
static void ping_gpio_init(void)
{
    GPIO_InitTypeDef g;
    uint8_t i;

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    g.Mode  = GPIO_MODE_OUTPUT_PP;
    g.Pull  = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;

    g.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 |
            GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5;
    HAL_GPIO_Init(GPIOA, &g);

    g.Pin = GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 |
            GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    HAL_GPIO_Init(GPIOB, &g);

    for (i = 0U; i < CAND_N; i++)
    {
        HAL_GPIO_WritePin(cand[i].port, cand[i].pin, GPIO_PIN_RESET);
    }
}

static void ping_all_low(void)
{
    uint8_t i;
    for (i = 0U; i < CAND_N; i++)
    {
        HAL_GPIO_WritePin(cand[i].port, cand[i].pin, GPIO_PIN_RESET);
    }
}

void pin_ping_run(void)
{
    uint8_t k;
    uint8_t i;
    uint16_t idr_val;
    uint8_t  ok;

    ping_gpio_init();
    HAL_Delay(300);

    ping_log("");
    ping_log("==== pin ping (minimal) ====");
    ping_log("A 段: 12 根候选脚逐个拉高 2s（LED 常亮=该脚为高）");
    ping_log("B 段: PA1 + PB11 同步 1Hz 翻转 10s（LED 跟着 EN 亮灭）");
    ping_log("万用表: 黑笔 GND，红笔点 LCD 第 6 脚 -> 应 0/3.3V 跳");

    for (;;)
    {
        /* ---------------- A 段：逐个引脚拉高，找线 ---------------- */
        for (k = 0U; k < CAND_N; k++)
        {
            ping_all_low();
            HAL_GPIO_WritePin(cand[k].port, cand[k].pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); /* LED 亮 */

            ping_log("----------------------------------------");
            ping_log(cand[k].name);
            ping_log("  [now HIGH] 这一根 = 3.3V，其余 = 0V");

            HAL_Delay(5);
            /* ODR=1 但 IDR=0 -> 被拉低（短路到地 / 电容太大 / 别处拉死） */
            if (cand[k].port == GPIOA)
            {
                idr_val = (uint16_t)((GPIOA->IDR >> k) & 1U);
            }
            else
            {
                idr_val = (uint16_t)((GPIOB->IDR >> (10U + (k - 6U))) & 1U);
            }
            ok = (uint8_t)(idr_val != 0U);
            ping_log(ok != 0U ? "  [read] IDR=1 ok"
                              : "  [read] !!! IDR=0 -> 这根脚被拉死了(短路到GND?)");

            HAL_Delay(2000);
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET); /* LED 灭 */
        }

        /* ---------------- B 段：EN 1Hz 翻转 ---------------- */
        ping_all_low();
        ping_log("========================================");
        ping_log("[EN] PA1 与 PB11 同步 1Hz 翻转 10 秒");
        ping_log("[EN] LED 跟 EN 一起亮灭：灯亮=3.3V, 灯灭=0V");
        ping_log("[EN] 量 LCD 第 6 脚（点母座背面焊点或杜邦线）");

        for (i = 0U; i < 10U; i++)
        {
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); /* LED 亮 = EN 高 */
            ping_log("[EN] = 1  (应读到 3.3V)");
            HAL_Delay(500);

            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   /* LED 灭 = EN 低 */
            ping_log("[EN] = 0  (应读到 0V)");
            HAL_Delay(500);
        }

        ping_log("[EN] 一轮结束，重新从 PA0 开始扫");
        HAL_Delay(500);
    }
}
