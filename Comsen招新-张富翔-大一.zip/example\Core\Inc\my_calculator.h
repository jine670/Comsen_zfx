#ifndef MY_CALCULATOR_H
#define MY_CALCULATOR_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 阶段 4：基本计算器（不带括号的四则运算 + AC）
 *
 * 这是一个独立、纯 C、不依赖任何外设和库的实现，可以直接在电脑上用
 * 单元测试验证，也可以编译进 STM32 工程。上层（按键扫描 / 串口 / LCD）
 * 负责把用户操作转换成 my_calc_key_t 后调用 my_calc_input()。
 */

typedef enum
{
    MY_CALC_KEY_0 = 0,
    MY_CALC_KEY_1,
    MY_CALC_KEY_2,
    MY_CALC_KEY_3,
    MY_CALC_KEY_4,
    MY_CALC_KEY_5,
    MY_CALC_KEY_6,
    MY_CALC_KEY_7,
    MY_CALC_KEY_8,
    MY_CALC_KEY_9,
    MY_CALC_KEY_DECIMAL,   /* 小数点 . */
    MY_CALC_KEY_ADD,       /* + */
    MY_CALC_KEY_SUB,       /* - */
    MY_CALC_KEY_MUL,       /* * */
    MY_CALC_KEY_DIV,       /* / */
    MY_CALC_KEY_EQUALS,    /* = */
    MY_CALC_KEY_CLEAR,     /* AC */
    MY_CALC_KEY_BACKSPACE, /* 退格（可选） */
    MY_CALC_KEY_COUNT
} my_calc_key_t;

typedef enum
{
    MY_CALC_OK = 0,      /* 正常 */
    MY_CALC_ERR_DIV0,    /* 除零 */
    MY_CALC_ERR_SYNTAX,  /* 语法错误（算式不完整） */
    MY_CALC_ERR_OVERFLOW /* 结果超出可显示范围 */
} my_calc_err_t;

/* 算式最长 16 个字符，正好占满 1602 的一行 */
#define MY_CALC_MAX_EXPR 16U

typedef struct
{
    char expr[MY_CALC_MAX_EXPR + 1U]; /* 正在输入的算式字符串 */
    uint8_t len;                      /* 算式当前长度 */
    uint8_t has_result;               /* 刚按过 =，result 有效 */
    uint8_t error;                    /* 取值见 my_calc_err_t */
    float result;                     /* 上一次 = 的计算结果 */
} my_calc_t;

/* 初始化 / AC 清空 */
void my_calc_init(my_calc_t *c);

/* 输入一个按键（数字 / 小数点 / 运算符 / = / AC / 退格） */
void my_calc_input(my_calc_t *c, my_calc_key_t key);

/* 生成 1602 两行显示内容：line1=算式，line2=结果或错误；不足 16 字符补空格 */
void my_calc_get_lines(const my_calc_t *c, char line1[16], char line2[16]);

#ifdef __cplusplus
}
#endif

#endif /* MY_CALCULATOR_H */
