#include "board_info.h"

#include <string.h>

#include "main.h"      /* HAL + 寄存器定义（DBGMCU / RCC / GPIOB / TIM3） */
#include "my_serial.h" /* USB 虚拟串口发送 */

/* ------------------------------------------------------------------------- */
/* 链接脚本里的符号：用来算「这份固件到底有多大、放在哪」                    */
/* ------------------------------------------------------------------------- */
extern uint32_t _etext;
extern uint32_t _sidata;
extern uint32_t _sdata;
extern uint32_t _edata;
extern uint32_t _sbss;
extern uint32_t _ebss;

#define FLASH_START_ADDR 0x08000000UL
#define FLASH_SIZE_REG   0x1FFFF7E0UL /* 16 位：Flash 容量（KB） */
#define UID_REG          0x1FFFF7E8UL /* 96 位唯一 ID */

static board_hw_info_t s_hw;
static board_sw_info_t s_sw;
static uint8_t s_ready;

/* ------------------------------------------------------------------------- */
/* 小工具：整数 -> 文本（不依赖 printf，省 Flash，也不会有重入问题）        */
/* ------------------------------------------------------------------------- */
typedef struct
{
    char buf[96];
    uint16_t len;
} line_t;

static void ln_reset(line_t *l)
{
    l->len = 0;
    l->buf[0] = '\0';
}

static void ln_ch(line_t *l, char c)
{
    if (l->len < (sizeof(l->buf) - 1U))
    {
        l->buf[l->len++] = c;
        l->buf[l->len] = '\0';
    }
}

static void ln_str(line_t *l, const char *s)
{
    while (*s != '\0')
    {
        ln_ch(l, *s++);
    }
}

static void ln_hex(line_t *l, uint32_t v, uint8_t digits)
{
    static const char hex[] = "0123456789ABCDEF";
    int8_t i;
    for (i = (int8_t)(digits - 1); i >= 0; i--)
    {
        ln_ch(l, hex[(v >> (uint8_t)(i * 4)) & 0xFU]);
    }
}

static void ln_dec(line_t *l, uint32_t v)
{
    char tmp[11];
    uint8_t n = 0;
    if (v == 0U)
    {
        ln_ch(l, '0');
        return;
    }
    while (v > 0U && n < sizeof(tmp))
    {
        tmp[n++] = (char)('0' + (v % 10U));
        v /= 10U;
    }
    while (n > 0U)
    {
        ln_ch(l, tmp[--n]);
    }
}

/* 频率（Hz）-> "72.0MHz" / "48000kHz"，LCD 上比较好看 */
static void ln_freq(line_t *l, uint32_t hz)
{
    if (hz >= 1000000UL)
    {
        ln_dec(l, hz / 1000000UL);
        ln_ch(l, '.');
        ln_dec(l, (hz / 100000UL) % 10UL);
        ln_str(l, "MHz");
    }
    else
    {
        ln_dec(l, hz / 1000UL);
        ln_str(l, "kHz");
    }
}

/* ------------------------------------------------------------------------- */
/* 一帧数据发到 USB 串口（加 \r\n，并留出时间给 USB 栈，避免丢包）           */
/* ------------------------------------------------------------------------- */
static void send_line(const char *s)
{
    uint16_t n = 0;
    while (s[n] != '\0')
    {
        n++;
    }
    my_serial_send((const uint8_t *)s, n);
    my_serial_send((const uint8_t *)"\r\n", 2U);
    HAL_Delay(4);
}

static void send_kv(const char *tag, const char *key, line_t *val)
{
    line_t l;
    ln_reset(&l);
    ln_str(&l, tag);
    ln_str(&l, key);
    ln_str(&l, " ");
    ln_str(&l, val->buf);
    send_line(l.buf);
}

/* ------------------------------------------------------------------------- */
/* CRC32（多项式 0xEDB88320，逐位算法，不会额外占用 1KB 查表空间）           */
/* ------------------------------------------------------------------------- */
static uint32_t crc32_flash(uint32_t start, uint32_t end)
{
    uint32_t crc = 0xFFFFFFFFUL;
    uint32_t addr;
    uint8_t bit;
    uint32_t byte;

    for (addr = start; addr < end; addr++)
    {
        /* 直接从 Flash 地址读：Cortex-M3 的代码/数据总线允许这样访问 */
        byte = *(volatile uint8_t *)addr;
        crc ^= byte;
        for (bit = 0; bit < 8U; bit++)
        {
            if ((crc & 1U) != 0U)
            {
                crc = (crc >> 1) ^ 0xEDB88320UL;
            }
            else
            {
                crc >>= 1;
            }
        }
    }
    return ~crc;
}

/* ------------------------------------------------------------------------- */
/* 版本号 -> 'A' 'B' 'C' ...（STM32F103 中容量的出厂版本编码）               */
/* ------------------------------------------------------------------------- */
static char rev_letter(uint16_t rev)
{
    switch (rev)
    {
    case 0x1000U: return 'A';
    case 0x2000U: return 'B';
    case 0x2001U: return 'C';
    case 0x2003U: return 'D';
    case 0x2004U: return 'E';
    default:      return '?';
    }
}

/* GPIOB 某个引脚的配置：返回 "IN" / "OUT" / "AF"，同时给出电平 */
static const char *pin_mode_str(uint32_t crl_or_crh, uint8_t pin)
{
    uint32_t nibble = (crl_or_crh >> ((pin % 8U) * 4U)) & 0xFU;
    uint32_t mode = nibble & 0x3U;
    uint32_t cnf = (nibble >> 2) & 0x3U;

    if (mode == 0U)
    {
        return "IN"; /* 输入：浮空/上拉/下拉/模拟，这里统一显示 IN */
    }
    if (cnf >= 2U)
    {
        return "AF"; /* 复用推挽 / 复用开漏 */
    }
    return "OUT";    /* 通用推挽 / 开漏 */
}

/* ------------------------------------------------------------------------- */
/* 采集信息                                                                  */
/* ------------------------------------------------------------------------- */
static void read_hw(board_hw_info_t *hw)
{
    uint32_t idcode = DBGMCU->IDCODE;
    uint32_t pll_in;
    uint32_t pll_mul;
    uint32_t cfgr = RCC->CFGR;

    memset(hw, 0, sizeof(*hw));

    hw->dev_id = (uint16_t)(idcode & 0xFFFFU);
    hw->rev_id = (uint16_t)(idcode >> 16);
    hw->rev_letter = rev_letter(hw->rev_id);

    hw->flash_kb = *(volatile uint16_t *)FLASH_SIZE_REG;

    hw->uid[0] = *(volatile uint32_t *)(UID_REG + 0U);
    hw->uid[1] = *(volatile uint32_t *)(UID_REG + 4U);
    hw->uid[2] = *(volatile uint32_t *)(UID_REG + 8U);

    /* 时钟树：HAL 算出来的频率 + 寄存器里的真实配置 */
    hw->sysclk_hz = HAL_RCC_GetSysClockFreq();
    hw->hclk_hz = HAL_RCC_GetHCLKFreq();
    hw->pclk1_hz = HAL_RCC_GetPCLK1Freq();
    hw->pclk2_hz = HAL_RCC_GetPCLK2Freq();

    hw->sysclk_src = (uint8_t)(cfgr & 0x3U);         /* SW[1:0] */
    hw->pll_src_hse = (uint8_t)((cfgr >> 16) & 1U);  /* PLLSRC */
    pll_mul = (cfgr >> 18) & 0xFU;
    hw->pll_mul = (uint8_t)(pll_mul + 2U);           /* 0000=x2 ... 1110=x16 */

    pll_in = (hw->pll_src_hse != 0U) ? BOARD_INFO_HW_HSE_HZ : (8000000UL / 2UL);
    if ((cfgr & (1UL << 22)) != 0U)                  /* USBPRE：1 = PLL/1  */
    {
        hw->usb_hz = pll_in * hw->pll_mul;
    }
    else                                             /*      0 = PLL/1.5 */
    {
        hw->usb_hz = (pll_in * hw->pll_mul) / 3UL * 2UL;
    }

    hw->flash_latency = (uint16_t)(FLASH->ACR & 0x7U);

    /* LCD + TTP229 全在 GPIOB 上：把真实配置抓下来 */
    hw->gpio_b_crl = GPIOB->CRL;
    hw->gpio_b_crh = GPIOB->CRH;
    hw->gpio_b_odr = GPIOB->ODR;
    hw->tim3_psc = (uint16_t)TIM3->PSC;
}

static void read_sw(board_sw_info_t *sw)
{
    uint32_t data_len = (uint32_t)&_edata - (uint32_t)&_sdata;
    uint32_t end = (uint32_t)&_sidata + data_len;

    memset(sw, 0, sizeof(*sw));

    sw->img_start = FLASH_START_ADDR;
    if (end < (uint32_t)&_etext)
    {
        end = (uint32_t)&_etext;
    }
    end = (end + 3UL) & ~3UL; /* 对齐到 4 字节 */
    sw->img_end = end;
    sw->img_size = end - FLASH_START_ADDR;

    sw->text_size = (uint32_t)&_etext - FLASH_START_ADDR;
    sw->data_size = data_len;
    sw->bss_size = (uint32_t)&_ebss - (uint32_t)&_sbss;

    sw->init_sp = *(volatile uint32_t *)FLASH_START_ADDR;
    sw->reset_vec = *(volatile uint32_t *)(FLASH_START_ADDR + 4U);

    sw->crc32 = crc32_flash(FLASH_START_ADDR, end);

    sw->build_date = __DATE__;
    sw->build_time = __TIME__;
}

void board_info_init(void)
{
    read_hw(&s_hw);
    read_sw(&s_sw);
    s_ready = 1U;
}

const board_hw_info_t *board_info_hw(void)
{
    if (s_ready == 0U)
    {
        board_info_init();
    }
    return &s_hw;
}

const board_sw_info_t *board_info_sw(void)
{
    if (s_ready == 0U)
    {
        board_info_init();
    }
    return &s_sw;
}

/* ------------------------------------------------------------------------- */
/* USB 串口完整输出                                                          */
/* ------------------------------------------------------------------------- */
void board_info_dump_serial(void)
{
    const board_hw_info_t *hw = board_info_hw();
    const board_sw_info_t *sw = board_info_sw();
    line_t l;
    uint8_t pin;

    send_line("");
    send_line("== ComSen board info ==");

    /* --- 硬件组：板子本身 --- */
    ln_reset(&l);
    ln_str(&l, BOARD_INFO_HW_MODEL);
    ln_str(&l, " ");
    ln_str(&l, BOARD_INFO_HW_PACKAGE);
    send_kv("[HW] model  ", "", &l);

    ln_reset(&l);
    ln_str(&l, "DEV_ID 0x");
    ln_hex(&l, hw->dev_id, 3);
    ln_str(&l, " REV_ID 0x");
    ln_hex(&l, hw->rev_id, 4);
    ln_str(&l, " (");
    ln_ch(&l, hw->rev_letter);
    ln_str(&l, ")");
    send_kv("[HW] chip   ", "", &l);

    ln_reset(&l);
    ln_dec(&l, hw->flash_kb);
    ln_str(&l, " KB");
    send_kv("[HW] flash  ", "", &l);

    ln_reset(&l);
    ln_hex(&l, hw->uid[0], 8);
    ln_ch(&l, '-');
    ln_hex(&l, hw->uid[1], 8);
    ln_ch(&l, '-');
    ln_hex(&l, hw->uid[2], 8);
    send_kv("[HW] UID    ", "", &l);

    ln_reset(&l);
    ln_str(&l, "SYSCLK ");
    ln_freq(&l, hw->sysclk_hz);
    ln_str(&l, "  HCLK ");
    ln_freq(&l, hw->hclk_hz);
    send_kv("[HW] clock  ", "", &l);

    ln_reset(&l);
    ln_str(&l, "APB1 ");
    ln_freq(&l, hw->pclk1_hz);
    ln_str(&l, "  APB2 ");
    ln_freq(&l, hw->pclk2_hz);
    ln_str(&l, "  USB ");
    ln_freq(&l, hw->usb_hz);
    send_kv("[HW] bus    ", "", &l);

    ln_reset(&l);
    ln_str(&l, hw->pll_src_hse ? "HSE 8MHz" : "HSI/2 4MHz");
    ln_str(&l, " PLL x");
    ln_dec(&l, hw->pll_mul);
    ln_str(&l, "  flash latency ");
    ln_dec(&l, hw->flash_latency);
    send_kv("[HW] source ", "", &l);

    ln_reset(&l);
    ln_str(&l, "CRL 0x");
    ln_hex(&l, hw->gpio_b_crl, 8);
    ln_str(&l, " CRH 0x");
    ln_hex(&l, hw->gpio_b_crh, 8);
    ln_str(&l, " ODR 0x");
    ln_hex(&l, hw->gpio_b_odr, 4);
    send_kv("[HW] GPIOB  ", "", &l);

    /* 每个引脚的模式 + 电平，分 4 行（PB0..PB15） */
    for (pin = 0U; pin < 16U; pin += 4U)
    {
        uint8_t i;
        ln_reset(&l);
        ln_str(&l, "PB");
        for (i = pin; i < (uint8_t)(pin + 4U); i++)
        {
            uint32_t cr = (i < 8U) ? hw->gpio_b_crl : hw->gpio_b_crh;
            ln_str(&l, (i < 10U) ? " 0" : " ");
            if (i < 10U)
            {
                ln_ch(&l, (char)('0' + i));
            }
            else
            {
                ln_dec(&l, i);
            }
            ln_ch(&l, '=');
            ln_str(&l, pin_mode_str(cr, i));
            ln_ch(&l, (hw->gpio_b_odr & (1UL << i)) ? '1' : '0');
            ln_str(&l, " ");
        }
        send_kv("[PIN] ", "", &l);
    }

    /* --- software 内：固件自己的信息 --- */
    ln_reset(&l);
    ln_str(&l, BOARD_INFO_SW_NAME);
    ln_str(&l, " ");
    ln_str(&l, BOARD_INFO_SW_VERSION);
    send_kv("[SW] name   ", "", &l);

    ln_reset(&l);
    ln_str(&l, sw->build_date);
    ln_str(&l, " ");
    ln_str(&l, sw->build_time);
    send_kv("[SW] build  ", "", &l);

    ln_reset(&l);
    ln_str(&l, "0x");
    ln_hex(&l, sw->img_start, 8);
    ln_str(&l, "-0x");
    ln_hex(&l, sw->img_end, 8);
    ln_str(&l, " ");
    ln_dec(&l, sw->img_size);
    ln_str(&l, "B");
    send_kv("[SW] image  ", "", &l);

    ln_reset(&l);
    ln_str(&l, "text ");
    ln_dec(&l, sw->text_size);
    ln_str(&l, "  data ");
    ln_dec(&l, sw->data_size);
    ln_str(&l, "  bss ");
    ln_dec(&l, sw->bss_size);
    send_kv("[SW] sizes  ", "", &l);

    ln_reset(&l);
    ln_str(&l, "SP 0x");
    ln_hex(&l, sw->init_sp, 8);
    ln_str(&l, "  RESET 0x");
    ln_hex(&l, sw->reset_vec, 8);
    send_kv("[SW] vector ", "", &l);

    ln_reset(&l);
    ln_str(&l, "0x");
    ln_hex(&l, sw->crc32, 8);
    send_kv("[SW] CRC32  ", "", &l);

    send_line("== end ==");
    send_line("");
}

/* ------------------------------------------------------------------------- */
/* LCD 分页显示                                                              */
/* ------------------------------------------------------------------------- */
void board_info_lcd_text(const char *text, char line[16])
{
    uint8_t i;
    for (i = 0U; i < 16U; i++)
    {
        line[i] = (text[i] != '\0') ? text[i] : ' ';
    }
}

uint8_t board_info_page_count(void)
{
    return 6U;
}

void board_info_lcd_page(uint8_t page, char line1[16], char line2[16])
{
    const board_hw_info_t *hw = board_info_hw();
    const board_sw_info_t *sw = board_info_sw();
    line_t l;

    switch (page % board_info_page_count())
    {
    case 0:
        ln_reset(&l);
        ln_str(&l, "ComSen HW Info");
        board_info_lcd_text(l.buf, line1);
        ln_reset(&l);
        ln_str(&l, BOARD_INFO_HW_MODEL);
        board_info_lcd_text(l.buf, line2);
        break;

    case 1:
        ln_reset(&l);
        ln_str(&l, "DEV 0x");
        ln_hex(&l, hw->dev_id, 3);
        ln_str(&l, " REV ");
        ln_ch(&l, hw->rev_letter);
        board_info_lcd_text(l.buf, line1);
        ln_reset(&l);
        ln_str(&l, "FLASH ");
        ln_dec(&l, hw->flash_kb);
        ln_str(&l, "KB ");
        ln_dec(&l, hw->sysclk_hz / 1000000UL);
        ln_str(&l, "MHz");
        board_info_lcd_text(l.buf, line2);
        break;

    case 2: /* 96 位 UID 分两行，每行 12 个十六进制字符 */
        ln_reset(&l);
        ln_str(&l, "UID ");
        ln_hex(&l, hw->uid[0], 8);
        ln_hex(&l, hw->uid[1] >> 16, 4);
        board_info_lcd_text(l.buf, line1);
        ln_reset(&l);
        ln_str(&l, "    ");
        ln_hex(&l, hw->uid[1] & 0xFFFFU, 4);
        ln_hex(&l, hw->uid[2], 8);
        board_info_lcd_text(l.buf, line2);
        break;

    case 3:
        ln_reset(&l);
        ln_str(&l, "SW ");
        ln_str(&l, BOARD_INFO_SW_NAME);
        board_info_lcd_text(l.buf, line1);
        ln_reset(&l);
        ln_str(&l, "VER ");
        ln_str(&l, BOARD_INFO_SW_VERSION);
        board_info_lcd_text(l.buf, line2);
        break;

    case 4:
        ln_reset(&l);
        ln_str(&l, "IMG ");
        ln_dec(&l, sw->img_size);
        ln_str(&l, " B");
        board_info_lcd_text(l.buf, line1);
        ln_reset(&l);
        ln_str(&l, "CRC32 ");
        ln_hex(&l, sw->crc32, 8);
        board_info_lcd_text(l.buf, line2);
        break;

    default:
        ln_reset(&l);
        ln_str(&l, "LCD RS:PB10 EN:11");
        board_info_lcd_text(l.buf, line1);
        ln_reset(&l);
        ln_str(&l, "D4-D7: PB12-15");
        board_info_lcd_text(l.buf, line2);
        break;
    }
}
