﻿#ifndef LCD_PROBE_H
#define LCD_PROBE_H

/*
 * 1602 硬件自检（不依赖 liblcd1602，自己直接拨 GPIOB）
 *
 * 目的：屏幕“背光亮但没字”时，用肉眼就能分出问题在哪一层：
 *
 *   阶段 1（约 2s） 第一行 "ComSen LCD TEST"，第二行 "1234567890ABCDEF"
 *                   → 能看见字：LCD、对比度、4 位数据线全都正常
 *   阶段 2（约 2s） 两行全部是实心黑块（CGRAM 自定义字符 0x1F x8）
 *                   → 只看得见黑块、看不见阶段 1 的字：D4-D7 有线没接好
 *   阶段 3（约 2s） 整屏“亮-灭”闪 3 次（显示开关命令）
 *                   → 有闪烁 = LCD 在执行命令，问题只在对比度/数据线
 *   阶段 4（约 3s） 一个黑块从第 2 行左边走到右边（测地址/光标）
 *
 * 自检期间 PC13 板载 LED 会“快闪”（100ms），自检结束回到正常模式（500ms 慢闪）。
 *
 * 把这个开关改成 0 就不再自检。
 */
#define LCD_PROBE_ENABLE 0

void lcd_probe_boot(void);

#endif /* LCD_PROBE_H */
