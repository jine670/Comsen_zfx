#include "lcd_probe.h"

#include "main.h"      /* HAL + GPIOB / TIM3 寄存器 */
#include "my_serial.h" /* USB 虚拟串口：把自检进度打出去，没屏也能看 */

/* 板子丝印（和 software.ioc、liblcd1602.a 反汇编都对得上）：
 *   RS = PB10   EN = PB11   D4..D7 = PB12..PB15
 */
#define LCD_RS_PIN GPIO_PIN_10
#define LCD_EN_PIN GPIO_PIN_11
#define LCD_D4_PIN GPIO_PIN_12
#define LCD_D5_PIN GPIO_PIN_13
#define LCD_D6_PIN GPIO_PIN_14
#define LCD_D7_PIN GPIO_PIN_15
#define LCD_DATA_PINS (LCD_D4_PIN | LCD_D5_PIN | LCD_D6_PIN | LCD_D7_PIN)

#define LED_PIN GPIO_PIN_13 /* PC13，低电平点亮 */

/* TIM3 已配成 1MHz，用来做微秒延时（和 lcd1602 库一样的做法） */
static void lcd_wait_us(uint16_t us)
{
    uint16_t start = (uint16_t)TIM3->CNT;
    while ((uint16_t)(TIM3->CNT - start) < us)
    {
    }
}

/* 送 4 个 bit：先放下 D4-D7 和 RS，再给 EN 一个高脉冲（下降沿锁存） */
static void lcd_nibble(uint8_t nibble, uint8_t rs)
{
    GPIOB->BRR = LCD_DATA_PINS; /* D4-D7 全低 */
    if ((nibble & 0x01U) != 0U) { GPIOB->BSRR = LCD_D4_PIN; }
    if ((nibble & 0x02U) != 0U) { GPIOB->BSRR = LCD_D5_PIN; }
    if ((nibble & 0x04U) != 0U) { GPIOB->BSRR = LCD_D6_PIN; }
    if ((nibble & 0x08U) != 0U) { GPIOB->BSRR = LCD_D7_PIN; }

    if (rs != 0U) { GPIOB->BSRR = LCD_RS_PIN; }
    else          { GPIOB->BRR = LCD_RS_PIN; }

    GPIOB->BSRR = LCD_EN_PIN; /* EN = 1 */
    lcd_wait_us(50);
    GPIOB->BRR = LCD_EN_PIN;  /* EN = 0 → 锁存 */
    lcd_wait_us(50);
}

static void lcd_cmd(uint8_t cmd)
{
    lcd_nibble((uint8_t)(cmd >> 4), 0U);
    lcd_nibble((uint8_t)(cmd & 0x0FU), 0U);
    HAL_Delay(2); /* 命令慢一点没关系，宁可稳 */
}

static void lcd_data(uint8_t data)
{
    lcd_nibble((uint8_t)(data >> 4), 1U);
    lcd_nibble((uint8_t)(data & 0x0FU), 1U);
    HAL_Delay(2);
}

/* 4 位模式的初始化：0x33 / 0x32 / 0x28 / 0x0C / 0x01 / 0x06
 * 这里故意把延时放得很宽松（上电 50ms、每条命令 5ms），
 * 这样即使是慢芯片 / 劣质模块也能初始化成功。 */
static void lcd_probe_init(void)
{
    HAL_Delay(50);

    GPIOB->BRR = LCD_EN_PIN;

    lcd_nibble(0x03U, 0U); HAL_Delay(5);
    lcd_nibble(0x03U, 0U); HAL_Delay(5);
    lcd_nibble(0x03U, 0U); HAL_Delay(5);
    lcd_nibble(0x02U, 0U); HAL_Delay(5); /* 切到 4 位模式 */

    lcd_cmd(0x28U); /* 4 位、2 行、5x8 */
    lcd_cmd(0x08U); /* 显示关 */
    lcd_cmd(0x01U); /* 清屏 */
    HAL_Delay(5);
    lcd_cmd(0x06U); /* 写入后地址 +1 */
    lcd_cmd(0x0CU); /* 显示开、光标关 */
}

/* CGRAM 里的第 0 号字符 = 实心黑块（每行 5 个点全亮） */
static void lcd_probe_cgram_block(void)
{
    uint8_t row;
    lcd_cmd(0x40U); /* 指向 CGRAM 0 号字符 */
    for (row = 0U; row < 8U; row++)
    {
        lcd_data(0x1FU);
    }
    lcd_cmd(0x80U); /* 回到 DDRAM 第一行开头 */
}

static void lcd_probe_clear(void)
{
    lcd_cmd(0x01U);
    HAL_Delay(2);
}

/* 在指定行写 16 个字符（line 0/1），不足补空格 */
static void lcd_probe_puts(uint8_t line, const char *s)
{
    uint8_t i;
    lcd_cmd((uint8_t)(line == 0U ? 0x80U : 0xC0U));
    for (i = 0U; i < 16U; i++)
    {
        uint8_t ch = 0x20U;
        if (s[i] != '\0')
        {
            ch = (uint8_t)s[i];
        }
        lcd_data(ch);
    }
}

/* 两行全部填成同一个字符 */
static void lcd_probe_fill(uint8_t ch)
{
    uint8_t i;
    lcd_cmd(0x80U);
    for (i = 0U; i < 32U; i++)
    {
        lcd_data(ch);
    }
}

/* 用灯“报数”：闪 n 下（250ms 亮/250ms 灭），后面停 800ms。
 * 自检走到第几个阶段，就能从闪几下直接读出来（不用看屏）。 */
static void led_code(uint8_t times)
{
    uint8_t i;
    for (i = 0U; i < times; i++)
    {
        HAL_GPIO_TogglePin(GPIOC, LED_PIN);
        HAL_Delay(250);
        HAL_GPIO_TogglePin(GPIOC, LED_PIN);
        HAL_Delay(250);
    }
    HAL_Delay(800);
}

/* 把一行进度播到 USB 虚拟串口（不依赖屏幕、不依赖电脑是否连着，
 * 没连着就发失败，不影响流程） */
static void probe_log(const char *s)
{
    uint16_t n = 0;
    while (s[n] != '\0')
    {
        n++;
    }
    my_serial_send((const uint8_t *)s, n);
    my_serial_send((const uint8_t *)"\r\n", 2U);
    HAL_Delay(5);
}

void lcd_probe_boot(void)
{
    uint8_t col;
    uint8_t i;

    lcd_probe_init();
    lcd_probe_cgram_block();
    probe_log("");
    probe_log("[probe] start");
    probe_log("[probe] init OK (0x33/0x32/0x28/0x08/0x01/0x06/0x0C)");

    /* ---- 阶段 1：文字（能动就说明整条链路都通）---- */
    probe_log("[probe] phase1 text `ComSen LCD TEST`");
    lcd_probe_clear();
    lcd_probe_puts(0U, "ComSen LCD TEST ");
    lcd_probe_puts(1U, "1234567890ABCDEF");
    led_code(1U);
    HAL_Delay(1500);

    /* ---- 阶段 2：整屏实心黑块（只有黑块没有字 → 数据线没接全）---- */
    probe_log("[probe] phase2 solid blocks");
    lcd_probe_clear();
    lcd_probe_fill(0x00U); /* 0 号字符就是刚才定义的实心块 */
    led_code(2U);
    HAL_Delay(1500);

    /* ---- 阶段 3：整屏亮灭闪 3 次（测命令通道）---- */
    probe_log("[probe] phase3 display on/off x3");
    led_code(3U);
    for (i = 0U; i < 3U; i++)
    {
        lcd_cmd(0x08U); /* 显示关 */
        HAL_Delay(250);
        lcd_cmd(0x0CU); /* 显示开 */
        HAL_Delay(250);
    }

    /* ---- 阶段 4：黑块从左走到右（测地址/光标）---- */
    probe_log("[probe] phase4 moving block");
    led_code(4U);
    for (col = 0U; col < 16U; col++)
    {
        lcd_cmd(0xC0U);
        for (i = 0U; i < 16U; i++)
        {
            lcd_data((uint8_t)(i == col ? 0x00U : 0x20U));
        }
        HAL_Delay(150);
    }

    lcd_probe_clear();
    lcd_cmd(0x0CU);
    probe_log("[probe] done - 正常计算器模式（LED 500ms 慢闪）");
}
