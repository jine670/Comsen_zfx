﻿#include "my_app.h"
#include "main.h"          /* HAL、HAL_Delay 等 */
#include "lcd1602.h"       /* 提供的显示库（阶段1验证用，这里继续复用） */
#include "my_calculator.h" /* 自己的计算器 */
#include "my_ttp229.h"     /* 自己的按键读取 */
#include "my_serial.h"     /* 自己的串口收发封装 */
#include "board_info.h"    /* 板卡硬件信息 + 固件(software)信息自检 */
#include "lcd_probe.h"     /* 开机时对 1602 做一遍硬件自检（可用宏关掉） */
#include "pin_ping.h"      /* 极简引脚测试（配万用表用） */
#include "my_terminal.h"   /* 串口 -> 1602 的打字机终端（自动换行 + 滚动） */

/* 1 = 只跑极简引脚测试固件（不跑计算器/显示）；0 = 正常功能 */
#define APP_PIN_PING 0

/* ---------------------------------------------------------------------------
 * 物理按键号 T0..T29 -> 计算器动作。
 * 依据板子丝印排列（已和示例库 libttp229.a 里的 channel_to_key 表核对一致）：
 *
 *   7 8 9        -> T10 T11 T12
 *   4 5 6        -> T15 T16 T17
 *   1 2 3        -> T20 T21 T22
 *   0 . =        -> T25 T26 T27
 *   * /          -> T18 T19
 *   + -          -> T23 T24
 *   ( )          -> T5 T6（括号属于阶段5，先忽略）
 *   AC           -> T0（这里把 T0 当清空键，请按自己板子的丝印确认）
 *
 * 值 -1 表示该键暂时不用。改这里即可调整布局。
 * ------------------------------------------------------------------------- */
static const int16_t key_action[30] = {
    /* T0  */ MY_CALC_KEY_CLEAR,
    /* T1  */ -1, /* T2 */ -1, /* T3 */ -1, /* T4 */ -1,
    /* T5  */ -1, /* T6 */ -1, /* 括号：阶段5再做 */
    /* T7  */ -1, /* T8 */ -1, /* T9 */ -1,
    /* T10 */ MY_CALC_KEY_7, /* T11 */ MY_CALC_KEY_8, /* T12 */ MY_CALC_KEY_9,
    /* T13 */ -1, /* T14 */ -1,
    /* T15 */ MY_CALC_KEY_4, /* T16 */ MY_CALC_KEY_5, /* T17 */ MY_CALC_KEY_6,
    /* T18 */ MY_CALC_KEY_MUL, /* T19 */ MY_CALC_KEY_DIV,
    /* T20 */ MY_CALC_KEY_1, /* T21 */ MY_CALC_KEY_2, /* T22 */ MY_CALC_KEY_3,
    /* T23 */ MY_CALC_KEY_ADD, /* T24 */ MY_CALC_KEY_SUB,
    /* T25 */ MY_CALC_KEY_0, /* T26 */ MY_CALC_KEY_DECIMAL,
    /* T27 */ MY_CALC_KEY_EQUALS,
    /* T28 */ -1, /* T29 */ -1,
};

typedef enum
{
    APP_MODE_CALC = 0, /* 显示计算器 */
    APP_MODE_SERIAL,   /* 显示电脑发来的串口内容 */
    APP_MODE_INFO,     /* 显示板卡硬件信息 / 固件信息（T1 进入，AC 退出） */
    APP_MODE_KEYTEST   /* 显示当前按下的按键（阶段 3：实时显示按键，串口发 k 进入） */
} app_mode_t;

static my_calc_t calc;
static app_mode_t mode = APP_MODE_CALC;
static uint8_t info_page; /* APP_MODE_INFO 下当前显示的页号 */

/* 阶段 3 按键实时显示用 */
static uint32_t key_raw_prev; /* 上一次的原始按键位图（用来找按下/抬起沿） */
static uint8_t  key_last_t = 0xFFU;

/* 开机横幅：上板后先看到字就说明 LCD + 主循环都活着，没按键前一直显示。 */
static uint8_t boot_screen = 1U;
static const char boot_line1[17] = "ComSen Calc     ";
static const char boot_line2[17] = "AC=T0  1+2=3    ";

/* ---------------------------------------------------------------------------
 * 简单的按键去抖：每个按键各自计数，连续 KEY_DEBOUNCE_CNT 次采样为高才算
 * 按下；只在「按下沿」返回一次该按键位，避免一次触摸触发多次。
 * 每 10ms 调用一次。
 * ------------------------------------------------------------------------- */
#define KEY_DEBOUNCE_CNT 3U

static uint8_t key_cnt[30];
static uint32_t key_held;

static uint32_t key_debounce(uint32_t raw)
{
    uint32_t pressed = 0;
    int i;
    for (i = 0; i < 30; i++)
    {
        uint32_t bit = 1UL << i;
        if (raw & bit)
        {
            if (key_cnt[i] < 255U)
            {
                key_cnt[i]++;
            }
        }
        else
        {
            key_cnt[i] = 0;
        }

        if (key_cnt[i] >= KEY_DEBOUNCE_CNT)
        {
            if ((key_held & bit) == 0U)
            {
                pressed |= bit; /* 新按下 */
            }
            key_held |= bit;
        }
        else
        {
            key_held &= ~bit;
        }
    }
    return pressed;
}

/* ---------------------------------------------------------------------------
 * 阶段 2：串口 -> 屏幕。
 * 真正的终端实现放在 my_terminal.c（自动换行、满屏滚动、退格），
 * 这里保留三个同名小函数转发一下，主循环代码不用改。
 * ------------------------------------------------------------------------- */
static void terminal_init(void)
{
    my_terminal_init();
}

static void terminal_feed(uint8_t ch)
{
    my_terminal_feed(ch);
}

static void terminal_lines(char line1[16], char line2[16])
{
    my_terminal_lines(line1, line2);
}

/* ---------------------------------------------------------------------------
 * 按键处理：把物理按键动作喂给计算器；AC 在串口模式下退回计算器模式。
 * ------------------------------------------------------------------------- */
static void handle_key_press(uint32_t pressed)
{
    int i;
    for (i = 0; i < 30; i++)
    {
        if (pressed & (1UL << i))
        {
            int16_t action = key_action[i];
            boot_screen = 0U;

            /* T1：进入 / 翻页「板卡信息」模式。第一次进入时把完整信息
             * （硬件型号、器件 ID、Flash、UID、时钟、GPIO、固件版本、
             *  镜像大小、CRC32）一次性打到 USB 虚拟串口。 */
            if (i == 1)
            {
                if (mode != APP_MODE_INFO)
                {
                    mode = APP_MODE_INFO;
                    info_page = 0U;
                    board_info_init();
                    board_info_dump_serial();
                }
                else
                {
                    info_page++;
                    if (info_page >= board_info_page_count())
                    {
                        info_page = 0U;
                    }
                }
                break;
            }

            if (action == MY_CALC_KEY_CLEAR)
            {
                if (mode == APP_MODE_SERIAL || mode == APP_MODE_INFO || mode == APP_MODE_KEYTEST)
                {
                    mode = APP_MODE_CALC; /* 串口/信息/按键模式下 AC 退回计算器 */
                }
                else
                {
                    my_calc_input(&calc, MY_CALC_KEY_CLEAR);
                }
            }
            else if (action >= 0)
            {
                my_calc_input(&calc, (my_calc_key_t)action);
                mode = APP_MODE_CALC;
            }
            break; /* 一次只处理一个键 */
        }
    }
}

/* ---------------------------------------------------------------------------
 * 初始化 / 主循环
 * ------------------------------------------------------------------------- */
void my_app_init(void)
{
#if APP_PIN_PING
    /* 极简引脚测试：PB10..PB15 依次拉高 + EN 1Hz 翻转，永不返回。
       测完把 APP_PIN_PING 改回 0 重新编译即可。 */
    pin_ping_run();
#endif

#if LCD_PROBE_ENABLE
    /* 先做 1602 自检（约 7 秒，LED 快闪），结束后再进入正常显示 */
    lcd_probe_boot();
#endif
    lcd1602_init();
    my_calc_init(&calc);
    my_serial_init();
    board_info_init(); /* 采集一次硬件 + 固件信息，后面按键随时可以再显示 */
    terminal_init();
    mode = APP_MODE_CALC;
    boot_screen = 1U;
    info_page = 0U;
}

/* ---------------------------------------------------------------------------
 * 阶段 3：按键实时显示用的小工具
 * ------------------------------------------------------------------------- */
/* 把一次“按下/抬起”打到串口，格式：KEY T12 DOWN / KEY T12 UP */
static void key_log_edge(uint8_t t, uint8_t down)
{
    char out[20];
    uint8_t n = 0U;
    out[n++] = 'K'; out[n++] = 'E'; out[n++] = 'Y'; out[n++] = ' ';
    out[n++] = 'T';
    if (t >= 10U) { out[n++] = (char)('0' + (t / 10U)); }
    out[n++] = (char)('0' + (t % 10U));
    out[n++] = ' ';
    if (down != 0U) { out[n++] = 'D'; out[n++] = 'O'; out[n++] = 'W'; out[n++] = 'N'; }
    else            { out[n++] = 'U'; out[n++] = 'P'; }
    out[n++] = '\r';
    out[n++] = '\n';
    my_serial_send((const uint8_t *)out, n);
}

/* 把一串文本填满 16 格（1602 只认 16 个字符，不认字符串结尾） */
static void fill16(const char *s, char line[16])
{
    uint8_t i;
    for (i = 0U; i < 16U; i++)
    {
        line[i] = (s[i] != '\0') ? s[i] : ' ';
    }
}

void my_app_run(void)
{
    /* 心跳灯：PC13 上的板载 LED（低电平点亮）。500ms 翻转一次，
     * 不用看屏幕、不用接串口，先眼看“固件到底在不在跑”。
     * 不想要这颗灯闪，把这个计数块删掉就行。 */
    static uint16_t heartbeat;

    for (;;)
    {
        /* 1) 扫按键（约每 10ms 一次） */
        uint32_t raw = my_ttp229_read_physical();
        uint32_t pressed = key_debounce(raw);

        if (mode == APP_MODE_KEYTEST)
        {
            /* 阶段 3 的重点：把每个按键的按下/抬起沿 实时 打到串口。
             * 屏幕那边同步显示 T 号 + 30 位位图。 */
            uint32_t changed = raw ^ key_raw_prev;
            int k;
            for (k = 0; k < 30; k++)
            {
                if ((changed & (1UL << k)) != 0U)
                {
                    key_log_edge((uint8_t)k, (uint8_t)((raw >> k) & 1U));
                }
            }
            if (pressed != 0U)
            {
                int j;
                for (j = 0; j < 30; j++)
                {
                    if ((pressed & (1UL << j)) != 0U)
                    {
                        key_last_t = (uint8_t)j;
                        break;
                    }
                }
            }
        }
        else if (pressed != 0U)
        {
            handle_key_press(pressed);
        }
        key_raw_prev = raw;

        /* 2) 处理串口收到的数据（阶段 2） */
        while (my_serial_available() > 0U)
        {
            uint8_t ch = my_serial_read();

            /* 串口发一个 i（info）：不用碰触摸屏也能进信息模式并输出完整信息。
             * 串口助手/命令行里敲个小写字母 i 回车就行（回车那下会进终端模式）。 */
            if (ch == 'i' || ch == 'I')
            {
                mode = APP_MODE_INFO;
                info_page = 0U;
                boot_screen = 0U;
                board_info_init();
                board_info_dump_serial();
                continue;
            }

            /* 串口发一个 k：进入「按键实时显示」模式（阶段 3） */
            if (ch == 'k' || ch == 'K')
            {
                static const char msg[] = "\r\n[keytest] press any touch key; each press -> KEY Tn DOWN\r\n";
                mode = APP_MODE_KEYTEST;
                key_raw_prev = 0U;
                key_last_t = 0xFFU;
                boot_screen = 0U;
                my_serial_send((const uint8_t *)msg, (uint16_t)(sizeof(msg) - 1U));
                continue;
            }

            /* 串口发一个 ?：把“现在屏幕上应该长什么样”原样打回电脑。
             * 屏还没调好时，用它验“串口 → 屏幕内容”这一步是否写对了。 */
            if (ch == '?')
            {
                char l1[16];
                char l2[16];
                char out[40];
                int k;
                terminal_lines(l1, l2);
                out[0] = '[';
                for (k = 0; k < 16; k++) { out[1 + k] = l1[k]; }
                out[17] = ']';
                out[18] = '[';
                for (k = 0; k < 16; k++) { out[19 + k] = l2[k]; }
                out[35] = ']';
                out[36] = '\r';
                out[37] = '\n';
                my_serial_send((const uint8_t *)out, 38U);
                continue;
            }

            my_serial_send(&ch, 1); /* 回显给电脑，方便验证 */
            terminal_feed(ch);
            mode = APP_MODE_SERIAL;
        }

        /* 3) 刷新 LCD */
        {
            char line1[16];
            char line2[16];
            if (mode == APP_MODE_SERIAL)
            {
                terminal_lines(line1, line2);
                boot_screen = 0U;
            }
            else if (mode == APP_MODE_INFO)
            {
                board_info_lcd_page(info_page, line1, line2);
            }
            else if (mode == APP_MODE_KEYTEST)
            {
                /* 第 1 行：最近按下的物理键号；第 2 行：30 位按键位图 */
                char buf[17];
                uint8_t n = 0U;
                uint8_t held = 0U;
                int k;
                static const char hex[] = "0123456789ABCDEF";

                buf[n++] = 'K'; buf[n++] = 'E'; buf[n++] = 'Y'; buf[n++] = ' ';
                buf[n++] = 'T';
                if (key_last_t == 0xFFU) { buf[n++] = '-'; buf[n++] = '-'; }
                else { buf[n++] = (char)('0' + (key_last_t / 10U)); buf[n++] = (char)('0' + (key_last_t % 10U)); }
                for (k = 0; k < 30; k++) { if ((raw & (1UL << k)) != 0U) { held++; } }
                buf[n++] = ' '; buf[n++] = '('; buf[n++] = (char)('0' + (held % 10U)); buf[n++] = ')';
                buf[n] = '\0';
                fill16(buf, line1);

                n = 0U;
                buf[n++] = 'B'; buf[n++] = 'M'; buf[n++] = 'P'; buf[n++] = ' ';
                for (k = 28; k >= 0; k -= 4) { buf[n++] = hex[(raw >> k) & 0xFU]; }
                buf[n] = '\0';
                fill16(buf, line2);
            }
            else if (boot_screen != 0U)
            {
                int i;
                for (i = 0; i < 16; i++)
                {
                    line1[i] = boot_line1[i];
                    line2[i] = boot_line2[i];
                }
            }
            else
            {
                my_calc_get_lines(&calc, line1, line2);
            }
            lcd1602_write_lines(line1, line2);
        }

        HAL_Delay(10);

        /* 50 x 10ms = 500ms 翻转 PC13，心眺灯 */
        heartbeat++;
        if (heartbeat >= 50U)
        {
            heartbeat = 0U;
            HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
        }
    }
}
