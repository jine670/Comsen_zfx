#include "my_ttp229.h"
#include "main.h" /* 提供 stm32f1xx_hal.h，定义 GPIOB / TIM3 */

/*
 * TTP229 读取协议（结合芯片手册 + 板上接线）：
 *
 * 每颗 TTP229 有 16 个感应通道。读取时，先给它的 SCL 数据线一个高电平，
 * 芯片会在 SDO 回读线上串行给出当前 16 个通道的状态，每一位的读取时序是：
 *
 *   1) 数据线拉高
 *   2) 等待芯片建立数据（约 5us）
 *   3) 采样回读线电平 -> 得到 1 bit
 *   4) 数据线拉低
 *   5) 等待（约 5us）
 *
 * 电平极性：SDO 是「开漏 + 上拉」，通道被触摸时输出低电平，所以采样到
 * **低电平**表示该位有效（bit = 1）。这与官方 libttp229.a 的反汇编
 * （tst + moveq 那段：IDR 该位为 0 才把 bit 置 1）完全一致。
 *
 * 这里直接用寄存器操作 GPIOB 和 TIM3，保证位翻转足够快、时序稳定。
 */

/* A/B 两片芯片的通道号 -> 物理按键号 映射表。
 * 0xFF 表示该通道没有对应的按键（芯片是 16 通道，但板子只用了 30 个键）。 */
static const uint8_t channel_to_key_a[16] = {
    7,  11, 6,  1,  0,  5,  10, 2,
    0xFF, 14, 9, 4, 3, 8, 13, 12
};

static const uint8_t channel_to_key_b[16] = {
    27, 15, 20, 25, 16, 21, 26, 17,
    22, 28, 23, 18, 29, 24, 19, 0xFF
};

/* 等待 TIM3 计数器再前进至少 (advance) 个计数。
 * TIM3 配成 1MHz，advance=4 大约就是 4~5us。 */
static void my_ttp229_delay(uint16_t advance)
{
    uint16_t start = (uint16_t)(TIM3->CNT);
    while ((uint16_t)(TIM3->CNT - start) <= advance)
    {
        /* 空转等待 */
    }
}

uint32_t my_ttp229_read_chip(uint16_t data_pin, uint16_t input_pin)
{
    uint32_t raw = 0;
    int bit;

    for (bit = 0; bit < 16; bit++)
    {
        /* 数据线拉高（BSRR 高 16 位是置位） */
        GPIOB->BSRR = (uint32_t)data_pin << 16U;
        my_ttp229_delay(4);

        /* 采样回读线（IDR 低 16 位对应引脚电平）
         * 注意极性：SDO 空闲被上拉为高，通道被触摸时拉低，因此「低电平=按下」，
         * 这里必须判 == 0，写成 != 0 会导致没碰按键也全部算按下。 */
        if ((GPIOB->IDR & input_pin) == 0U)
        {
            raw |= (1UL << bit);
        }

        /* 数据线拉低（BSRR 低 16 位是复位） */
        GPIOB->BSRR = (uint32_t)data_pin;
        my_ttp229_delay(4);
    }

    return raw;
}

uint32_t my_ttp229_read_physical(void)
{
    uint32_t raw_a = my_ttp229_read_chip(GPIO_PIN_6, GPIO_PIN_7);
    uint32_t raw_b = my_ttp229_read_chip(GPIO_PIN_8, GPIO_PIN_9);

    uint32_t bitmap = 0;
    int ch;

    /* 把 A/B 两片的通道号映射成物理按键号 T0..T29 */
    for (ch = 0; ch < 16; ch++)
    {
        if ((raw_a & (1UL << ch)) != 0U)
        {
            uint8_t key = channel_to_key_a[ch];
            if (key != 0xFF)
            {
                bitmap |= (1UL << key);
            }
        }
        if ((raw_b & (1UL << ch)) != 0U)
        {
            uint8_t key = channel_to_key_b[ch];
            if (key != 0xFF)
            {
                bitmap |= (1UL << key);
            }
        }
    }

    return bitmap;
}
