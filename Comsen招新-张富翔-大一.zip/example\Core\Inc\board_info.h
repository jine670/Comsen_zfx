#ifndef BOARD_INFO_H
#define BOARD_INFO_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 板卡自检 / 信息读取模块（纯 C，编译进固件，烧进去就能用）
 *
 * 干什么：
 *   1) 读「Comsen 硬件组」这块板子的硬件信息 —— 全部直接读芯片寄存器，
 *      不需要 ST-Link 也能拿到：
 *        - 型号 / 器件 ID / 版本号（DBGMCU->IDCODE）
 *        - Flash 容量（0x1FFFF7E0）
 *        - 96 位唯一 ID（0x1FFFF7E8）
 *        - 时钟树实测值（SYSCLK/HCLK/APB1/APB2/USB、HSE、PLL 倍频、Flash 等待周期）
 *        - GPIOB 的 CRL/CRH/ODR（LCD 与 TTP229 到底配成什么了，一眼可查）
 *   2) 读「software 内」的信息 —— 也就是这份固件自己：
 *        - 程序名 / 版本 / 编译时间
 *        - 镜像在 Flash 里的地址范围、字节数
 *        - .text / .data / .bss 大小
 *        - 中断向量表的初始 SP 和复位入口
 *        - 整片镜像的 CRC32（用来核对「烧进去的是不是这一版」）
 *
 * 输出方式：
 *   - board_info_dump_serial()：把所有信息按 ASCII 行打到 USB 虚拟串口
 *   - board_info_lcd_page()   ：把信息分页显示到 1602（每页 2 行 x 16 字符）
 */

/* ---- 软件信息（改这里就能改串口/LCD 上显示的版本号）---- */
#define BOARD_INFO_SW_NAME    "ComSen Calc"
#define BOARD_INFO_SW_VERSION "1.0.0"

/* ---- 硬件信息（来自 software.ioc，不是猜的）---- */
#define BOARD_INFO_HW_MODEL   "STM32F103C8T6"
#define BOARD_INFO_HW_PACKAGE "LQFP48"
#define BOARD_INFO_HW_HSE_HZ  8000000UL   /* .ioc: RCC HSE 8MHz，PLL x9 */

typedef struct
{
    uint16_t dev_id;      /* 0x410 = STM32F103 中容量（0x414 是高容量）*/
    uint16_t rev_id;      /* 芯片版本原始值 */
    char     rev_letter;  /* A/B/C...，认不出就是 '?' */
    uint16_t flash_kb;    /* Flash 容量寄存器给出的 KB */
    uint32_t uid[3];      /* 96 位唯一 ID */

    uint32_t sysclk_hz;
    uint32_t hclk_hz;
    uint32_t pclk1_hz;
    uint32_t pclk2_hz;
    uint32_t usb_hz;
    uint8_t  sysclk_src;  /* 0=HSI 1=HSE 2=PLL */
    uint8_t  pll_mul;     /* 2..16 */
    uint8_t  pll_src_hse; /* 1 = PLL 用 HSE */
    uint16_t flash_latency;

    uint32_t gpio_b_crl;
    uint32_t gpio_b_crh;
    uint32_t gpio_b_odr;
    uint16_t tim3_psc;
} board_hw_info_t;

typedef struct
{
    uint32_t img_start;   /* 0x08000000 */
    uint32_t img_end;     /* 镜像最后一个字节之后 */
    uint32_t img_size;
    uint32_t crc32;
    uint32_t init_sp;     /* 向量表第 0 项 */
    uint32_t reset_vec;   /* 向量表第 1 项（带 Thumb 位） */
    uint32_t text_size;
    uint32_t data_size;
    uint32_t bss_size;
    const char *build_date;
    const char *build_time;
} board_sw_info_t;

/* 采集一次信息，上电后调用一次即可（可重复调用，用来刷新） */
void board_info_init(void);

const board_hw_info_t *board_info_hw(void);
const board_sw_info_t *board_info_sw(void);

/* 把全部信息打到 USB 虚拟串口（每行以 \r\n 结尾） */
void board_info_dump_serial(void);

/* LCD 分页显示：页数 */
uint8_t board_info_page_count(void);

/* 取第 page 页的内容，两个 16 字节缓冲（不做字符串结尾，和 lcd1602 库一致） */
void board_info_lcd_page(uint8_t page, char line1[16], char line2[16]);

/* 一行文本（不超过 16 字）写到 LCD：方便别处直接显示 */
void board_info_lcd_text(const char *text, char line[16]);

#ifdef __cplusplus
}
#endif

#endif /* BOARD_INFO_H */
