#ifndef MY_APP_H
#define MY_APP_H

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 应用层：把「按键读取 -> 计算器 -> LCD 显示」和「串口 -> LCD 显示」
 * 串成一个裸机主循环（不用 RTOS，符合 README 推荐）。
 */

/* 上电后调用一次 */
void my_app_init(void);

/* 主循环，永不返回；main() 里直接调用它即可 */
void my_app_run(void);

#ifdef __cplusplus
}
#endif

#endif /* MY_APP_H */
